﻿using System;
using System.IO;
using System.Text;
using youFastConversion;

namespace Example2 // how to convert csv file to binaram and then convert to json file
{
    class Program
    {
        static void Main(string[] args)
        {
            binaram currentProcess = new binaram(); // new one instance of the in-memory "Binaram" processing
            csv2BinaramInput currentInput = new csv2BinaramInput();  // new one instance of csv2Binaram properties
            currentInput.filePath = "Cashflow.csv"; // configure to process one data file "Cashflow.csv"
            binaram csv2Binaram = currentProcess.csv2Binaram(currentInput); // use current csv2Binaram properties to run csv2Binaram method           

            binaram2JSONsetting setBinaram2JSON = new binaram2JSONsetting(); 
            setBinaram2JSON.tableName = "Cashflow";
            StringBuilder binaram2JSON = currentProcess.binaram2JSONMultithread(csv2Binaram, setBinaram2JSON);
            using (StreamWriter toDisk = new StreamWriter(setBinaram2JSON.tableName + ".json"))
            {
                toDisk.Write(binaram2JSON);
                toDisk.Close();
            }
            var Filelength = new FileInfo("Cashflow.csv").Length;
            Console.WriteLine("Cashflow.json has filelength of " + Filelength + " was generated.");
            Console.ReadLine();
        }
    }
}

